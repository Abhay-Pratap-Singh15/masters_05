﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mca_Console_cal
{
    internal class ClassMethod
    {
        public void TestTry()
        {
            Console.WriteLine("test try class method");
        }
    }
}

    